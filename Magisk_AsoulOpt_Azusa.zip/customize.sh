CFG_PATH="/data/adb/naki"
MODS_PATH="/data/adb/modules"

mkdir -p $CFG_PATH $MODS_PATH
mode=`grep mode= /sdcard/Android/naki/asopt/asopt.conf`
[ -z $mode ] && mode=`grep mode= $CFG_PATH/asopt.conf`
[ -z $mode ] && mode="mode=0"

echo "
- 配置文件位于 $CFG_PATH
- The config file is at $CFG_PATH
"
echo "# mode：运行模式
# 0：硬亲和，理论上表现更好
# 1：软迁移，帧率可能更稳定
# 2：硬迁移，帧率可能更稳定
# 模式 2 仅适用于不低于以下版本的内核：
# 高通：5.10 联发科：5.15

# mode: Operation Mode
# 0: Affinity, performs better in theory
# 1: Soft migrate, fps maybe more stable
# 2: Hard migrate, fps maybe more stable
# mode 2 is only available on kernels no older than:
# Qualcomm: 5.10 Mediatek: 5.15

# ***修改此文件后重启生效***
# ***Reboot after modification to take effect***

$mode" > $CFG_PATH/asopt.conf

chmod +x $MODPATH/AsoulOpt; killall -15 AsoulOpt
rm -rf $MODPATH/customize.sh /data/adb/asopt /data/asopt.conf /sdcard/Android/asopt /sdcard/Android/naki/asopt
cp -af $MODPATH $MODS_PATH; sh $MODS_PATH/asoul_affinity_opt/service.sh
