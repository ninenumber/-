packages="com.android.packageinstaller"

check_support() {
    android_ver=$(getprop ro.build.version.release)
    ui_print "- Checking support..."
    if [ "$android_ver" -lt 15 ]; then
        abort "- Your ColorOS Version is not supported"
    fi
}

uninstall_updates() {
    ui_print "- Uninstalling installer updates..."
    for pkg in $packages; do
        pm uninstall-system-updates $pkg >/dev/null 2>&1
    done
}

get_package_info() {
    pkg=$1
    installed=$(pm list packages | grep -q $pkg && echo true || echo false)
    path=$(pm path $pkg | sed 's/package://')
    folder=$(dirname "$path")
}

find_replace_folder() {
    local search_dir="/data/adb/modules/$MODID"
    local replace_file=$(find "$search_dir" -name ".replace" -type f)
    if [ -n "$replace_file" ]; then
        local replace_folder=$(dirname "$replace_file")
        replace_folder=${replace_folder#$search_dir}
        if [ -z "$replace_folder" ]; then
            echo "$1"
        else
            echo "$replace_folder"
        fi
    else
        echo "$1"
    fi
}

install_package() {
    installer=$1
    partition=$2
    replace_folder=$3
    
    ui_print "- Replacing with $installer"
    
    mkdir -p "$MODPATH$partition/priv-app/PackageInstaller"
    cp -rf "$MODPATH/files/${installer}.apk" "$MODPATH$partition/priv-app/PackageInstaller"
    
    replace_folder=$(find_replace_folder "$replace_folder")
    
    REPLACE="
    $replace_folder
    "
}

add_installer() {
    ui_print "- Installing files for Android $android_ver"
    
    uninstall_updates
    
    for pkg in $packages; do
        get_package_info "$pkg"
        if [ "$installed" = "true" ]; then
            if [[ "$path" == *product* ]]; then
                partition=/system/product
                replace_folder="/system$folder"
            elif [[ "$path" == *system_ext* ]]; then
                partition=/system/system_ext
                replace_folder="/system$folder"
            elif [[ "$path" == *vendor* ]]; then
                partition=/system/vendort
                replace_folder="/system$folder"
            elif [[ "$path" == *system* ]]; then
                partition=/system
                replace_folder="$folder"            
            fi
            
            case $pkg in
                com.android.packageinstaller) install_package "PackageInstaller" "$partition" "$replace_folder" ;;
            esac
            return
        fi
    done
    
    abort "- No supported package installer found"
}

clean_files() {
    rm -rf "$MODPATH/addon" "$MODPATH/files" 2>/dev/null
    rm -f "$MODPATH/install.sh" 2>/dev/null
    rm -rf /data/resource-cache/* /data/system/package_cache/* 2>/dev/null
    touch "$MODPATH/PUIAOSPPackageInstall/remove"
}

run_install() {
    mods_center
    check_support
    add_installer
    clean_files
}

run_install